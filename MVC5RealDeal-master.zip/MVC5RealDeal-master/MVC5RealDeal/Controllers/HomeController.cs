﻿using MVC5RealDeal.Models.EntityManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using MVC5RealDeal.Models.ViewModel;
using MVC5RealDeal.Security;

namespace MVC5RealDeal.Controllers
{
    public class HomeController : Controller
    {
        [Authorize]
        public ActionResult Index()
        {
            UserManager UM = new UserManager();
            ViewBag.UserID = UM.GetUserID(User.Identity.Name);
            return View();
        }

        [Authorize]

        public ActionResult Welcome()
        {

            return View();

        }
        [AuthorizeRoles("Admin")]
        public ActionResult AdminOnly() { return View(); }


        public ActionResult UnAuthorized()
        { return View(); }

        [AuthorizeRoles("Admin")]
        public ActionResult ManageUserPartial(string status = "")
        {
            if (User.Identity.IsAuthenticated)
            {
                string loginName = User.Identity.Name;
                UserManager UM = new UserManager();
                UserDataView UDV = UM.GetUserDataView(loginName);
                string message = string.Empty;
                if (status.Equals("update"))
                    message = "Update Successful";
                else if (status.Equals("delete"))
                    message = "Delete Successful";
                ViewBag.Message = message;
                return PartialView(UDV);
            }
            return RedirectToAction("Index", "Home");
        }
        [Authorize]
        public ActionResult EditProfile()
        {
            string loginName = User.Identity.Name;
            UserManager UM = new UserManager();
            UserProfileView UPV = UM.GetUserProfile(UM.GetUserId(loginName));
            return View(UPV);
        }
        [HttpPost]
        [Authorize]
        public ActionResult EditProfile(UserProfileView profile)
        {
            if (ModelState.IsValid)
            {
                UserManager UM = new UserManager(); UM.UpdateUserAccount(profile);
                ViewBag.Status = "Update Sucessful!";
            }
            return View(profile);
        }
        
        [Authorize]
        public ActionResult ShoutBoxPartial()
        { return PartialView(); }
        [Authorize]
        public ActionResult SendMessage(int userID, string message)
        {
            UserManager UM = new UserManager();
            UM.AddMessage(userID, message);
            return Json(new { success = true });
        }
        [Authorize]
        public ActionResult GetMessages()
        {
            UserManager UM = new UserManager(); return Json(UM.GetAllMessages(), JsonRequestBehavior.AllowGet);
        }
    }
}